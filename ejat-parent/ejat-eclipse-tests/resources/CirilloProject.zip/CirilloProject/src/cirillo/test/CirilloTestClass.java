package cirillo.test;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import io.ejat.After;
import io.ejat.AfterClass;
import io.ejat.Before;
import io.ejat.BeforeClass;
import io.ejat.Test;

public class CirilloTestClass {
	private static Log logger = LogFactory.getLog(CirilloTestClass.class);
	
	/**
	 * Constructor
	 */
	public CirilloTestClass() {
		logger.info("Constructor");		
	}
	
	/**
	 * {@literal @}BeforeClass method
	 */
	@BeforeClass
	public void testBeforeClass() {
		logger.info("@BeforeClass annotated method");
	}
	
	/**
	 * {@literal @}Before method
	 */
	@Before
	public void testBefore() {
		logger.info("@Before annotated method");
	}
	
	/**
	 * {@literal @}Test method 1
	 */
	@Test
	public void testTest1() {
		logger.info("@Test annotated method - 1");
	}
	
	/**
	 * {@literal @}Test method 2
	 */
	@Test
	public void testTest2() {
		logger.info("@Test annotated method - 2");
	}
	
	/**
	 * {@literal @}Test method 3
	 */
	@Test
	public void testTest3() {
		logger.info("@Test annotated method - 3");
	}
	
	@After
	public void testAfter() {
		logger.info("@After annotated method");
	}
	
	/**
	 * {@literal @}AfterClass method
	 */
	@AfterClass
	public void testAfterClass() {
		logger.info("@AfterClass annotated method");
	}
}
